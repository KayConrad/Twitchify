#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <stdlib.h>
#include <fstream>
using namespace std;

int main() {

	// Channel ID Number {0,99999}
	// Average Viewers {0,50000}
	// Monthly Stream Time {1 hour, 160 hours}
	// Partnered Boolean {true / false} based on Average Viewers and Monthly Stream Time
	// Mature Boolean {true / false}

	// Up to 3 Games Played
	vector<string> gamesMasterList{ "Just Chatting","World of Warcraft","Grand Theft Auto V","Call of Duty: Warzone","League of Legends","Valorant","Fortnite","Ark: Survival Evolved","Minecraft","Sports","Pokemon Scarlet/Violet","Apex Legends","Dota 2","The Callisto Protocol","Call of Duty: Modern Warfare II","Counter-Strike: Global Offensive","Overwatch 2","FIFA 23","Variety","Dead by Daylight" };
	cout << "Total Number of Possible Games: " << gamesMasterList.size() << endl;

	// Up to 5 Tags
	vector<string> tagsMasterList{ "Playing with Viewers","AMA","Challenge Run","Speed Run","First Playthrough","Art Commissions","Backseat Gaming Allowed","3D Printing","ADHD","Hot Tub","LGBTQ","Birthday","Cozy","Drops Enabled","Educational","Farming","Gambling","JJK Marathon","Anime","Lesbian","Makeup","Man","NA","Party Game","PC","Concert","Robotics","Roleplay","Safe Space","Comedy","SpyXFamily","Naruto","Theater","Drama","Twitch Rivals","Vegan","World","Woman","Wii","You" };
	cout << "Total Number of Possible Tags: " << tagsMasterList.size() << endl;

	// Up to 1 Language
	vector<string> languagesMasterList{ "French","English","Korean","German","Spanish","Portuguese","Russian","Turkish","Tagalog","Italian","Swedish","Japanese","Arabic","Chinese","Vietnamese","Czech","Thai","Hungarian","Polish","Greek" };
	cout << "Total Number of Possible Languages: " << languagesMasterList.size() << endl;



	// Write to a CSV

	ofstream myFile("RandomStreamerData.csv");

	myFile << "Channel ID,Average Viewers,Monthly Stream Time,Partnered,Mature,Games,Tags,Language\n";

	int numEntries = 100000; // Change to 100000 for Final CSV
	for (int j = 0; j < numEntries; j++) {

		myFile << j << ",";
		int averageViewers = rand() % 50001;
		int monthlyStreamTime = (rand() % 160) + 1;
		myFile << averageViewers << ",";
		myFile << monthlyStreamTime << ",";
		bool partnered = (averageViewers > 3 && monthlyStreamTime > 10) ? true : false;
		string partneredResult = (partnered) ? "TRUE" : "FALSE";
		myFile << partneredResult << ",";
		int mature = rand() % 2;
		string matureResult = (mature == 1) ? "TRUE" : "FALSE";
		myFile << matureResult << ",";

		set<int>::iterator it1;
		set<int>::iterator it2;

		set<int> gamesIndices;
		for (int i = 0; i < 3; i++) {
			gamesIndices.insert(rand() % 20);
		}
		for (it1 = gamesIndices.begin(); it1 != gamesIndices.end(); ++it1) {
			myFile << gamesMasterList[*it1] << ".";
		}
		myFile << ",";

		set<int> tagsIndices;
		for (int i = 0; i < 5; i++) {
			tagsIndices.insert(rand() % 40);
		}
		for (it2 = tagsIndices.begin(); it2 != tagsIndices.end(); ++it2) {
			myFile << tagsMasterList[*it2] << ".";
		}
		myFile << ",";

		myFile << languagesMasterList[rand() % 20];

		myFile << endl;

	}

	return 0;

}